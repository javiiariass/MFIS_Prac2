El archivo .cmd debe estar en la carpeta raiz de use
No es necesario cargar previamente el modelo, el cmd ya lo hace